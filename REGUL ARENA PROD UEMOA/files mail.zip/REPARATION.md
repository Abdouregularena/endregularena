# 🛠️ Réparer le site et activer le salon — 3 actions sur GitHub

**Ce qui s'est passé :** mon `server.js` + `package.json` ont fait démarrer le mauvais moteur, ce qui a coupé la connexion. On remet ton vrai serveur (`index.js`) et on branche le salon sur les routes qu'il possède déjà. **Tes données (comptes, scores) sont intactes.**

> ⚠️ **N'ajoute PAS PostgreSQL.** Ton serveur utilise déjà sa base sur le volume. Si tu as commencé à ajouter une variable, tu peux la laisser tomber.

Tout se fait sur GitHub (`github.com/Abdouregularena/endregularena`). Tu fais ces 3 actions, GitHub envoie à Railway, et Railway redéploie tout seul.

---

## Action 1 — Remettre le bon `package.json` (répare la connexion)
1. Sur GitHub, à la racine du dépôt, ouvre le fichier **`package.json`**.
2. Clique sur l'icône **crayon** (Edit) → efface tout → colle le contenu du **nouveau `package.json`** que je te donne → **Commit changes**.

👉 Effet : Railway relance ton vrai serveur **`index.js`**, et la **connexion par email remarche**.

## Action 2 — Mettre le `index.html` corrigé (active le salon)
Le site servi est celui du dossier **`public`**. Il faut donc remplacer **`public/index.html`** :
1. Sur GitHub, entre dans le dossier **`public`**.
2. Clique **Add file → Upload files**.
3. Dépose le nouveau **`index.html`** (il remplace l'ancien) → **Commit changes**.

👉 Effet : le menu **Communauté 💬** parle maintenant aux bonnes adresses (`/chat/...`) de ton serveur.

## Action 3 — Supprimer mon `server.js` (inutile maintenant)
1. À la racine, ouvre le fichier **`server.js`**.
2. Clique sur l'icône **corbeille** (Delete) → **Commit changes**.

*(Optionnel, pour faire propre : tu peux aussi supprimer le fichier `index.html` qui est à la racine — c'est un doublon ignoré — et `INSTALLATION_RAILWAY.md`.)*

---

## Vérifier que tout est revenu
1. Attends que Railway affiche le déploiement en vert (onglet **Deployments**).
2. Ouvre ton site → **connecte-toi par email** : ça doit remarcher. ✅
3. Va dans **Communauté 💬**, écris un message → il apparaît.
4. Teste depuis un **2e téléphone** : le message s'affiche en quelques secondes. 🎉

## Si la connexion ne revient pas
Regarde les **Logs** Railway. Si le déploiement échoue, c'est presque toujours `package.json` : vérifie qu'il contient bien `"start": "node index.js"`. Envoie-moi le message d'erreur, je le corrige.

## Ensuite (le salon marche déjà côté serveur)
Les **messages privés** existent aussi déjà côté serveur (`/dm/...`). Une fois le salon validé, on ajoutera leur écran dans le site, puis le **suivi des tournois en direct**.
