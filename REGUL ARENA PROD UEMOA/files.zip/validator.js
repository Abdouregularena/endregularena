'use strict';

// ── Pays UEMOA valides ────────────────────────────────────
const VALID_COUNTRIES = ['SN','CI','ML','BF','BJ','NE','TG','GW'];

// ── Validation email — TOUS les emails acceptés ───────────
// (gmail, yahoo, hotmail, outlook, et emails institutionnels)
function validateInstitutionalEmail(email) {
  if (!email || typeof email !== 'string') {
    return { ok: false, reason: 'Email requis.' };
  }

  const clean = email.trim().toLowerCase();

  // Format basique : contient @ et un domaine avec point
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!emailRegex.test(clean)) {
    return { ok: false, reason: 'Format d\'email invalide. Exemple : nom@gmail.com' };
  }

  // Longueur raisonnable
  if (clean.length > 254) {
    return { ok: false, reason: 'Email trop long.' };
  }

  return { ok: true };
}

// ── Validation nom ────────────────────────────────────────
function validateName(name) {
  if (!name || typeof name !== 'string') {
    return { ok: false, reason: 'Nom requis.' };
  }
  const clean = name.trim();
  if (clean.length < 2) {
    return { ok: false, reason: 'Nom trop court (minimum 2 caractères).' };
  }
  if (clean.length > 100) {
    return { ok: false, reason: 'Nom trop long (maximum 100 caractères).' };
  }
  return { ok: true };
}

// ── Validation profil / institution ──────────────────────
function validateProfile(profile) {
  if (!profile || typeof profile !== 'string') {
    return { ok: false, reason: 'Institution / organisation requise.' };
  }
  const clean = profile.trim();
  if (clean.length < 2) {
    return { ok: false, reason: 'Institution trop courte (minimum 2 caractères).' };
  }
  if (clean.length > 200) {
    return { ok: false, reason: 'Institution trop longue (maximum 200 caractères).' };
  }
  return { ok: true };
}

// ── Validation pays ───────────────────────────────────────
function validateCountry(country) {
  if (!country || typeof country !== 'string') {
    return { ok: false, reason: 'Pays requis.' };
  }
  if (!VALID_COUNTRIES.includes(country.trim().toUpperCase())) {
    return {
      ok: false,
      reason: 'Pays invalide. Sélectionnez un pays UEMOA : ' + VALID_COUNTRIES.join(', ') + '.'
    };
  }
  return { ok: true };
}

module.exports = {
  validateInstitutionalEmail,
  validateName,
  validateProfile,
  validateCountry,
};
