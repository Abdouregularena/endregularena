'use strict';

/* ================================================================
   REGUL ARENA — Source serveur des questions de duel (CORRIGÉ)
   ----------------------------------------------------------------
   Avant : ce module tentait d'extraire « const PACKS = [ ... ] » du
   fichier public/index.html. Le site n'utilise plus cette variable,
   donc l'extraction échouait → « Pack introuvable ou vide ».

   Maintenant : on charge les vraies questions UEMOA officielles
   depuis data/quiz_uemoa.json (déjà présent côté serveur). Le duel
   peut ainsi démarrer pour n'importe quel pack envoyé par le site
   (rfe-uemoa, bale-umoa, mix, P1..P5, general).
================================================================ */

const fs   = require('fs');
const path = require('path');

function loadPool() {
  try {
    const p    = path.join(__dirname, 'data', 'quiz_uemoa.json');
    const data = JSON.parse(fs.readFileSync(p, 'utf8'));
    const byId = Array.isArray(data.packs) ? data.packs : [];
    const all  = [];
    byId.forEach(pk => (pk.questions || []).forEach(q => all.push(q)));
    if (all.length === 0) throw new Error('aucune question dans quiz_uemoa.json');
    console.log(`[packs] ${all.length} questions chargées (${byId.length} packs) depuis data/quiz_uemoa.json`);
    return { byId, all };
  } catch (e) {
    console.error('[packs] ERREUR chargement :', e.message);
    return { byId: [], all: [] };
  }
}

const POOL = loadPool();

/** Renvoie un pack par id (P1..P5) ; sinon un pack synthétique = toutes les questions. */
function getPack(id) {
  const exact = POOL.byId.find(p => p.id === id);
  if (exact) return exact;
  if (POOL.all.length > 0) return { id: id || 'general', questions: POOL.all };
  return null;
}

/** Tire `count` questions mélangées (Fisher-Yates) du pack demandé. */
function pickQuestions(packId, count) {
  const pack = getPack(packId);
  if (!pack || !Array.isArray(pack.questions) || pack.questions.length === 0) return null;
  const src = pack.questions.slice();
  for (let i = src.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [src[i], src[j]] = [src[j], src[i]];
  }
  const n   = Math.max(1, Number(count) || 10);
  const out = [];
  for (let i = 0; i < n; i++) out.push(src[i % src.length]);
  return out;
}

module.exports = { PACKS: POOL.byId, getPack, pickQuestions };
